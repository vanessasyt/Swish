'use client';

import { FormEvent, useState } from 'react';

const outfits = [
  { label: 'THE EVERYDAY ICON', name: 'Vintage leather jacket', size: 'UK 10 · Very good', price: 'SWAP ONLY', image: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=900&q=85', className: 'jacket' },
  { label: 'SOFT SPOT', name: 'The perfect knit', size: 'UK S · Like new', price: 'SWAP ONLY', image: 'https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=900&q=85', className: 'knit' },
  { label: 'OFF-DUTY', name: 'Your new denim era', size: 'W28 · Good', price: 'SWAP ONLY', image: 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=900&q=85', className: 'denim' },
];

export default function Home() {
  const [email, setEmail] = useState('');
  const [area, setArea] = useState('');
  const [interest, setInterest] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [activeCard, setActiveCard] = useState(0);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!email.trim()) return;
    // Demo interaction: connect this form to a database or email platform before launch.
    setSubmitted(true);
  }

  return (
    <main>
      <div className="announcement"><span className="announcement-dot" /> LONDON, WE’RE GETTING DRESSED DIFFERENTLY <span className="announcement-arrow">↗</span></div>
      <header className="nav shell">
        <a href="#top" className="wordmark" aria-label="SWISH home">swish<span>®</span></a>
        <nav aria-label="Main navigation"><a href="#how">How it works</a><a href="#why">The why</a></nav>
        <a className="nav-cta" href="#waitlist">GET EARLY ACCESS <span>↗</span></a>
      </header>

      <section className="hero shell" id="top">
        <div className="hero-copy">
          <div className="eyebrow"><span className="tiny-star">✳</span> YOUR WARDROBE, WITH A SOCIAL LIFE</div>
          <h1>Good clothes.<br /><em>Good people.</em><br />Great chemistry.</h1>
          <p className="hero-lede">Your next favourite fit is already out there. Swipe for the clothes, match on the vibe, then meet IRL.</p>
          <div className="hero-actions"><a className="button button-dark" href="#waitlist">GET ON THE LIST <span>↗</span></a><span className="micro-note">No shopping cart. Just good taste.</span></div>
          <div className="hero-proof"><div className="avatar-stack"><span>J</span><span>M</span><span>A</span><span>+</span></div><p><strong>A new way to refresh your wardrobe.</strong><br />Made for the people who make your style.</p></div>
        </div>
        <div className="hero-visual" aria-label="Fashion discovery preview">
          <div className="scribble scribble-top">YOUR NEXT<br />FAVOURITE FIT <span>↘</span></div>
          <div className="hero-photo"><div className="photo-overlay"><span className="photo-label">FIT CHECK #014</span><span className="photo-location">LONDON, UK · 0.8 MI</span></div><div className="hero-sticker">LESS BUYING.<br /><i>MORE SWISHING.</i> ✳</div></div>
          <div className="swipe-card"><div><span className="card-kicker">ON YOUR RADAR</span><strong>Vintage leather</strong><small>UK 10 · Very good</small></div><div className="swipe-actions"><button type="button" aria-label="Pass on featured outfit" onClick={() => setActiveCard((activeCard + 1) % outfits.length)} className="pass">×</button><button type="button" aria-label="Like featured outfit" onClick={() => setActiveCard((activeCard + 1) % outfits.length)} className="like">♥</button></div></div>
          <div className="orbit-note">SWIPE <span>✳</span> SWAP <span>✳</span> SOCIAL</div>
        </div>
      </section>

      <div className="ticker" aria-label="Swipe, swap, social"><div className="ticker-track">{Array.from({ length: 4 }).map((_, i) => <span key={i}>SWIPE <b>✳</b> SWAP <b>✳</b> SOCIAL <b>✳</b> RE-WEAR THE FEELING <b>✳</b></span>)}</div></div>

      <section className="section how shell" id="how">
        <div className="section-heading"><div><span className="eyebrow">01 / IT’S A MATCH</span><h2>It’s not just<br />a <em>fit.</em></h2></div><p>Think dating-app energy, but the first thing you fall for is the jacket. Mutual interest gets you in the door. The rest is up to you.</p></div>
        <div className="steps-grid">
          <article className="step-card step-peach"><div className="step-top"><span>01</span><span>THE DISCOVERY</span></div><div className="step-image image-one"><span className="floating-tag">WANT IT? ♥</span></div><h3>Swipe on the good stuff.</h3><p>Find pieces with personality. The kind you’ll wear on repeat.</p><span className="step-doodle">↗</span></article>
          <article className="step-card step-lilac"><div className="step-top"><span>02</span><span>THE CHEMISTRY</span></div><div className="step-image image-two"><span className="match-bubble">IT’S A<br /><b>MATCH!</b> ✳</span></div><h3>Match on more than clothes.</h3><p>Like each other’s pieces, unlock their wardrobe and find your shared vibe.</p><span className="step-doodle">♡</span></article>
          <article className="step-card step-green"><div className="step-top"><span>03</span><span>THE IRL MOMENT</span></div><div className="step-image image-three"><span className="meet-tag">MEET CUTE<br />MEET SWAP</span></div><h3>Take the match offline.</h3><p>Chat, agree on a swap and meet up. Maybe leave with a new friend, too.</p><span className="step-doodle">↗</span></article>
        </div>
      </section>

      <section className="wardrobe-section" id="wardrobe"><div className="shell wardrobe-inner"><div className="wardrobe-copy"><span className="eyebrow">02 / YOUR NEXT OBSESSION</span><h2>Someone’s<br />“over it” is your<br /><em>“need it.”</em></h2><p>That jacket they never reach for? Your new signature. Give great clothes another chapter — and find the person whose style just gets yours.</p><a href="#waitlist" className="text-link">FIND YOUR NEXT FIT <span>↗</span></a><div className="wardrobe-index"><span>0{activeCard + 1}</span><div className="index-line"><i style={{ width: `${((activeCard + 1) / outfits.length) * 100}%` }} /></div><span>03</span></div><div className="wardrobe-controls"><button type="button" aria-label="Previous garment" onClick={() => setActiveCard((activeCard + outfits.length - 1) % outfits.length)}>←</button><button type="button" aria-label="Next garment" onClick={() => setActiveCard((activeCard + 1) % outfits.length)}>→</button></div></div><div className="product-display"><div className="product-photo" style={{ backgroundImage: `url('${outfits[activeCard].image}')` }}><span className="product-label">{outfits[activeCard].label}</span><span className="product-heart">♡</span></div><div className="product-meta"><div><h3>{outfits[activeCard].name}</h3><p>{outfits[activeCard].size}</p></div><span className="swap-only">{outfits[activeCard].price}</span></div><div className="product-bottom"><span>AVAILABLE TO SWAP</span><span>✳ SWISH SELECTS</span></div></div><div className="wardrobe-side-note">GOOD TASTE<br />GOES AROUND. ↗</div></div></section>

      <section className="why-section shell" id="why"><div className="why-art"><div className="why-photo"><span className="why-stamp">WEAR<br />IT AGAIN<br /><b>AND AGAIN.</b></span></div><span className="why-caption">STYLE IS BETTER WHEN IT’S SHARED.</span></div><div className="why-copy"><span className="eyebrow">03 / THE BIGGER PICTURE</span><h2>More wearing.<br />Less <em>wasting.</em></h2><p>We don’t need a whole new wardrobe to feel like someone new. SWISH is built around giving the clothes we already have more life — and making it easier to connect along the way.</p><div className="why-points"><div><span>✳</span><p><b>Good for your rotation</b><br />A fresh-to-you fit without another new purchase.</p></div><div><span>✳</span><p><b>Good for your people</b><br />Shared taste is a pretty good place to start.</p></div><div><span>✳</span><p><b>Good things go around</b><br />Keep wearable clothes moving, not forgotten.</p></div></div></div></section>

      <section className="waitlist-section" id="waitlist"><div className="waitlist-shape shape-left">✳</div><div className="waitlist-content"><span className="eyebrow">LONDON, THIS ONE’S FOR YOU</span><h2>Your wardrobe<br />called. It wants<br /><em>new energy.</em></h2><p>Be first in line for the clothes, the connections and the swaps. Join the SWISH early-access list.</p>{submitted ? <div className="success-message"><span>✳</span><div><b>You’re on the list. (In spirit.)</b><p>This demo isn’t saving emails yet. Connect a form service before launch so we can actually keep your spot.</p></div></div> : <form className="waitlist-form" onSubmit={handleSubmit}><label className="sr-only" htmlFor="email">Your email address</label><input id="email" type="email" placeholder="Your email address" value={email} onChange={(e) => setEmail(e.target.value)} required /><button type="submit">COUNT ME IN <span>↗</span></button><label className="sr-only" htmlFor="area">London area</label><select id="area" value={area} onChange={(e) => setArea(e.target.value)}><option value="">Where in London are you? (optional)</option><option>North London</option><option>South London</option><option>East London</option><option>West London</option><option>Central London</option><option>Greater London / outside</option></select><label className="sr-only" htmlFor="interest">What brings you to SWISH?</label><select id="interest" value={interest} onChange={(e) => setInterest(e.target.value)}><option value="">What brings you here? (optional)</option><option>Finding unique clothes</option><option>Saving money</option><option>Meeting people</option><option>Making fashion more circular</option><option>All of the above</option></select><small>By joining, you agree to receive SWISH launch updates. No spam, no weird stuff.</small></form>}<div className="waitlist-footnote"><span>✳</span> SWIPE. SWAP. SOCIAL.</div></div><div className="waitlist-shape shape-right">♡</div></section>

      <footer className="footer shell"><a href="#top" className="wordmark">swish<span>®</span></a><p>Better fits. New connections. Less stuff going to waste.</p><div className="footer-right"><span>MADE FOR LONDON, WITH LOVE.</span><a href="#top">BACK TO TOP ↑</a></div><div className="footer-bottom"><span>© 2026 SWISH. ALL GOOD THINGS GO AROUND.</span><span>SWIPE. SWAP. SOCIAL.</span></div></footer>
    </main>
  );
}
