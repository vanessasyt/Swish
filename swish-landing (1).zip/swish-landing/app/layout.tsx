import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'SWISH — Swipe. Swap. Social.',
  description: 'Find your next favourite fit and the people behind the style. Discover clothes, match on taste and swap in real life.',
  applicationName: 'SWISH',
  themeColor: '#f6f3ec',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
